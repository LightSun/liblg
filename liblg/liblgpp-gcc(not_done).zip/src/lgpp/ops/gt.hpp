#ifndef LGPP_OPS_GT_HPP
#define LGPP_OPS_GT_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct Gt {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Gt& imp, Thread<VM>& thread) {
    Stack& s = get_stack(thread);
    Val y = pop(s), x = pop(s);
    push(s, thread.vm.Bool, x > y);
    return &op+1;
  }

}

#endif
