#ifndef LGPP_OPS_JOIN_HPP
#define LGPP_OPS_JOIN_HPP

#include "../op.hpp"
#include "../val.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct Join {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Join& imp, Thread<VM>& thread) {
    auto& s = get_stack(thread);
    auto tid = pop(s, thread.vm.Thread);
    VM &vm(thread.vm);
    auto& t = get_thread(vm, tid);

    if (!t.imp.joinable()) { throw runtime_error("Cannot join main thread"); }
    t.imp.join();
    push(s, thread.vm.Stack, get_stack(t));
    
    using lock_t = unique_lock<shared_mutex>;
    //VM::lock_t lock(vm.thread_mutex);
    lock_t lock(vm.thread_mutex);
    auto found = vm.threads.find(tid);
    if (found == vm.threads.end()) { throw runtime_error("Thread not found"); }
    vm.threads.erase(found);

    return &op+1;
  }

}

#endif
