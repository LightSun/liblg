#ifndef LGPP_OPS_POP_STACK_HPP
#define LGPP_OPS_POP_STACK_HPP

#include "../op.hpp"

namespace lgpp::ops {

  struct PopStack {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const PopStack& imp, Thread<VM>& thread) {
    auto v = pop_stack(thread);
    push(get_stack(thread), thread.vm.Stack, v);
    return &op+1;
  }

}

#endif
