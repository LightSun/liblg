#ifndef LGPP_OPS_TYPE_OF_HPP
#define LGPP_OPS_TYPE_OF_HPP

#include "../val.hpp"
#include "../op.hpp"

namespace lgpp::ops {

  struct TypeOf {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const TypeOf& imp, Thread<VM>& thread) {
    auto& s = get_stack(thread);
    push(s, thread.vm.Meta, &get_type(pop(s)));
    return &op+1;
  }

}

#endif
