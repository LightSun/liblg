#ifndef LGPP_OPS_LT_HPP
#define LGPP_OPS_LT_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct Lt {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Lt& imp, Thread<VM>& thread) {
    auto& s = get_stack(thread);
    Val<VM> y = pop(s), x = pop(s);
    push(s, thread.vm.Bool, x < y);
    return &op+1;
  }

}

#endif
