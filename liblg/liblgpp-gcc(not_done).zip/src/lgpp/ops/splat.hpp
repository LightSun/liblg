#ifndef LGPP_OPS_SPLAT_HPP
#define LGPP_OPS_SPLAT_HPP

#include "../op.hpp"
#include "../stack.hpp"
#include "../thread.hpp"

namespace lgpp::ops {

  struct Splat {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Splat& imp, Thread<VM>& thread) {
    auto& ts = get_stack(thread);
    auto s = pop(ts, thread.vm.Stack);
    copy(s.begin(), s.end(), back_inserter(ts));
    return &op+1;
  }

}

#endif
