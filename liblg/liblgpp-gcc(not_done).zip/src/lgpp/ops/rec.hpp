#ifndef LGPP_OPS_REC_HPP
#define LGPP_OPS_REC_HPP

#include "../op.hpp"
#include "../val.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct Rec {};

   template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Rec& imp, Thread<VM>& thread) {
    auto c = peek_call(thread);
    if (!c) { throw ERun(op.pos, "Rec outside of call"); } 
    return &op - op.pc + c->pc;
  }

}

#endif
