#ifndef LGPP_OPS_PUSH_STACK_HPP
#define LGPP_OPS_PUSH_STACK_HPP

#include "../op.hpp"

namespace lgpp::ops {

  struct PushStack {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const PushStack& imp, Thread<VM>& thread) {
    push_stack(thread);
    return &op+1;
  }

}

#endif
