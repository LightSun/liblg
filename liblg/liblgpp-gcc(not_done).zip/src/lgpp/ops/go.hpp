#ifndef LGPP_OPS_GO_HPP
#define LGPP_OPS_GO_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../label.hpp"

namespace lgpp::ops {

  struct Go {
    Go(const Label& target): target(target) {}
    const Label& target;
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Go& imp, Thread<VM>& thread) {
    return &op - op.pc + *imp.target.pc;
  }

}

#endif
