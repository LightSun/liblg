#ifndef LGPP_OPS_AND_HPP
#define LGPP_OPS_AND_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct And {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const And& imp, Thread<VM>& thread) {
    Stack<VM>& s = get_stack(thread);
    Val<VM> y = pop(s), x = pop(s);
    push(s, is_true(x) ? y : x);
    return &op+1;
  }

}

#endif
