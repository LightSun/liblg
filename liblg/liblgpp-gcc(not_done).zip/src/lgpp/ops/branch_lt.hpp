#ifndef LGPP_OPS_BRANCH_LT_HPP
#define LGPP_OPS_BRANCH_LT_HPP

#include <optional>

#include "../stack.hpp"
#include "../val.hpp"
#include "../op.hpp"
#include "branch_const.hpp"

namespace lgpp::ops {
  template<typename VM>
  struct BranchLt: BranchConst<VM> {
    template <typename...Args>
    BranchLt(Label& target, size_t x_offs, Args&&...args):
      BranchConst<VM>(target, x_offs, forward<Args>(args)...) {}
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const BranchLt<VM>& imp, Thread<VM>& thread) {
    auto& s = get_stack(thread);
    return (*(s.end()-imp.x_offs-1) < imp.y) ? &op-op.pc + *imp.target.pc : &op+1;
  }

}

#endif
