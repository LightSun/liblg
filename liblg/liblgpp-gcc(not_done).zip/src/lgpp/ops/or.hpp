#ifndef LGPP_OPS_OR_HPP
#define LGPP_OPS_OR_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct Or {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Or& imp, Thread<VM>& thread) {
    Stack<VM>& s = get_stack(thread);
    Val<VM> y = pop(s), x = pop(s);
    push(s, is_true(x) ? x : y);
    return &op+1;
  }

}

#endif
