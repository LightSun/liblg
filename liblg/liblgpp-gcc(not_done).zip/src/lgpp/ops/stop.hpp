#ifndef LGPP_OPS_STOP_HPP
#define LGPP_OPS_STOP_HPP

#include "../val.hpp"
#include "../op.hpp"

namespace lgpp::ops {

  struct Stop {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Stop& imp, Thread<VM>& thread) { return nullptr; }

}

#endif
