#ifndef LGPP_OPS_START_CORO_HPP
#define LGPP_OPS_START_CORO_HPP

#include "../op.hpp"
#include "../val.hpp"
#include "../vm.hpp"

namespace lgpp::ops {

  struct StartCoro {
    StartCoro(Label& target): target(target) {}
    Label& target;
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const StartCoro& imp, Thread<VM>& thread) {
    push(get_stack(thread), thread.vm.Coro, *imp.target.pc);
    return &op+1;
  }
  
}

#endif
