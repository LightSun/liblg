#ifndef LGPP_OPS_SUB_HPP
#define LGPP_OPS_SUB_HPP

#include "../stack.hpp"
#include "../val.hpp"
#include "../op.hpp"

namespace lgpp::ops {

  struct Sub {};

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Sub& imp, Thread<VM>& thread) {
    auto& s = get_stack(thread);
    Val<VM> y(pop(s)), x(pop(s));
    push(s, x - y);
    return &op+1;
  }

}

#endif
