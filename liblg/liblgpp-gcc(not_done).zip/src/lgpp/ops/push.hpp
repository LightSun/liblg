#ifndef LGPP_OPS_PUSH_HPP
#define LGPP_OPS_PUSH_HPP

#include "../stack.hpp"
#include "../val.hpp"
#include "../op.hpp"
#include "../thread.hpp"

namespace lgpp::ops {

  template <typename VM>
  struct Push {
    template <typename...Args>
    Push(Args&&...args): val(forward<Args>(args)...) {}
      
    Val<VM> val;
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Push<VM>& imp, Thread<VM>& thread) {
    get_stack(thread).push_back(imp.val);
    return &op+1;
  }

}

#endif
