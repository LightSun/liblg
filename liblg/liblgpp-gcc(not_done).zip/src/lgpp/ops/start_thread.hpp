#ifndef LGPP_OPS_START_THREAD_HPP
#define LGPP_OPS_START_THREAD_HPP

#include "../op.hpp"
#include "../val.hpp"
#include "../label.hpp"

namespace lgpp::ops {

  struct StartThread {
    StartThread(Label& target): target(target) {}
    Label& target;
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const StartThread& imp, Thread<VM>& thread) {
    auto &vm(thread.vm);
    auto& t = start_thread(vm, thread, [&vm, &imp]() { eval(vm, *imp.target.pc); });
    push(get_stack(thread), Val(thread.vm.Thread, t.id));
    return &op+1;
  }

}

#endif
