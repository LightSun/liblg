#ifndef LGPP_OPS_LABEL_HPP
#define LGPP_OPS_LABEL_HPP

#include "../val.hpp"
#include "../op.hpp"
#include "../label.hpp"

namespace lgpp::ops {

  struct Label {
    Label(PC pc): target(pc) { }
    lgpp::Label target;
  };

  template <typename VM>
  inline const Op<VM>* eval(const Op<VM>& op, const Label& imp, Thread<VM>& thread) {
      return &op+1; }

}

#endif
