#ifndef LGPP_ENV_HPP
#define LGPP_ENV_HPP

#include <map>
#include <string>
#include <functional>

#include "lgpp/val.hpp"

namespace lgpp {

  using namespace std;
  
  template<typename VM>
  struct Env {
    Env(VM &vm): vm(vm) {}
    
    VM &vm;
    map<string, Val<VM>> bindings;
  };

  template <typename VM, typename...Args>
  void let(Env<VM>& env, string id, Args&&...args) {
    env.bindings.insert(make_pair(id, Val(forward<Args>(args)...)));
  }

  template <typename VM>
  inline optional<Val<VM>> find(Env<VM>& env, const string& id) {
    auto found = env.bindings.find(id);
    if (found == env.bindings.end()) { return nullopt; }
    return found->second;
  }
}

#endif
