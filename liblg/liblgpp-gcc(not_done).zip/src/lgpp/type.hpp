#ifndef LGPP_TYPE_HPP
#define LGPP_TYPE_HPP

#include "lgpp/trait.hpp"

namespace lgpp {
  template <typename VM,typename T>
  struct Type: Trait<VM> {
    using Val = T;
    
    Type(VM& vm, string name, initializer_list<Trait<VM> *> parents = {})
        : Trait<VM>(vm, name, parents) {}
  };
}

#endif
