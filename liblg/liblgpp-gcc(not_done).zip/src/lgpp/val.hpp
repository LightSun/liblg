#ifndef LGPP_VAL_HPP
#define LGPP_VAL_HPP

#include <memory>

#include "lgpp/pc.hpp"
#include "lgpp/pos.hpp"
#include "lgpp/type.hpp"

namespace lgpp {  
  using namespace std;
  
  template<typename VM>
  struct Thread;
  
  template<typename VM>
  struct Trait;
  
  template<typename VM, typename T>
  struct Type;

  template<typename VM>
  struct Val;

  template<typename VM>
  Trait<VM>& get_type(const Val<VM> &val);

  namespace types {

    template <typename VM,typename T>
    PC call(Type<VM, T>&, const T&, Thread<VM>&, PC, Pos);

    template <typename VM,typename T>
    void dump(Type<VM, T>&, const T&, ostream&);

    template <typename VM,typename T>
    void say(Type<VM, T>&, const T&, ostream&);

    template <typename VM,typename T>
    bool is_true(Type<VM, T>&, const T&);

    template <typename VM,typename T>
    bool eq(Type<VM, T>&, const T&, Val<VM>);

    template <typename VM,typename T>
    bool gt(Type<VM, T>&, const T&, Val<VM>);

    template <typename VM,typename T>
    bool lt(Type<VM, T>&, const T&, Val<VM>);

    template <typename VM,typename T>
    Val<VM> add(Type<VM, T>&, const T&, Val<VM>);

    template <typename VM,typename T>
    Val<VM> sub(Type<VM, T>&, const T&, Val<VM>);

  }

  template <typename VM0>
  struct Val {
    template <typename VM>
    struct Imp {
      virtual ~Imp() = default;

      virtual Trait<VM>& type() const = 0;

      virtual PC call(Thread<VM0>&, PC, Pos) const = 0;

      virtual void dump(ostream&) const = 0;
      virtual void say(ostream&) const = 0;
      
      virtual bool is_true() const = 0;
      virtual bool eq(Val) const = 0;
      virtual bool gt(Val) const = 0;
      virtual bool lt(Val) const = 0;

      virtual Val add(Val) const = 0;
      virtual Val sub(Val) const = 0;
    };

    template <typename VM, typename T>
    struct TImp: Imp<VM> {
      TImp(Type<VM, T>& type, T data): _type(type), data(move(data)) {}

      Trait<VM>& type() const override { return _type; }

      PC call(Thread<VM>& thread, PC pc, Pos pos) const override {
          return types::call(_type, data, thread, pc, pos);
      }

      void dump(ostream& out) const override { types::dump(_type, data, out); }
      void say(ostream& out) const override { types::say(_type, data, out); }

      bool is_true() const override { return types::is_true(_type, data); }
      bool eq(Val y) const override { return types::eq(_type, data, y); }
      bool gt(Val y) const override { return types::gt(_type, data, y); }
      bool lt(Val y) const override { return types::lt(_type, data, y); }

      Val add(Val y) const override { return types::add(_type, data, y); }
      Val sub(Val y) const override { return types::sub(_type, data, y); }

      Type<VM, T>& _type;
      T data;
    };

    template <typename T, typename...Args>
    Val(Type<VM0, T>& type, Args&&...args):
        imp(make_shared<TImp<VM0,T>>(type, T(forward<Args>(args)...))) {}

    Val(const Val<VM0>&) = default;

    Val(Val<VM0>&&) = default;

    Val<VM0> &operator =(const Val<VM0> &) = default;
    
    template <typename T>
    const T& as(Type<VM0, T>& type) const {
      if (&get_type(*this) != &type) { throw runtime_error("Wrong type"); }
      return dynamic_cast<const TImp<VM0, T>&>(*imp).data;
    }
    
    shared_ptr<const Imp<VM0>> imp;
  };

  template <typename VM>
  inline Trait<VM>& get_type(const Val<VM> &val) { return val.imp->type(); }
  
  namespace types {
    template <typename VM,typename T>
    PC call(Type<VM,T>& type, const T& imp, Thread<VM>& thread, PC pc, Pos pos) {
        throw runtime_error("Not implemented");
    }

    template <typename VM,typename T>
    void dump(Type<VM,T>& type, const T& imp, ostream& out) { throw runtime_error("Not implemented"); }

    template <typename VM,typename T>
    void say(Type<VM,T>& type, const T& imp, ostream& out) { dump(type, imp, out); }

    template <typename VM,typename T>
    bool is_true(Type<VM,T> &type, const T& x) { return true; }

    template <typename VM,typename T>
    bool eq(Type<VM,T> &type, const T& x, Val<VM> y) { return x == y.as(type); }

    template <typename VM,typename T>
    bool gt(Type<VM,T> &type, const T& x, Val<VM> y) { return x > y.as(type); }

    template <typename VM,typename T>
    bool lt(Type<VM,T> &type, const T& x, Val<VM> y) { return x < y.as(type); }

    template <typename VM,typename T>
    Val<VM> add(Type<VM,T> &type, const T& x, Val<VM> y) { throw runtime_error("Not implemented"); }

    template <typename VM,typename T>
    Val<VM> sub(Type<VM,T> &type, const T& x, Val<VM> y) { throw runtime_error("Not implemented"); }
  }

  template <typename VM>
  inline PC call(const Val<VM>& x, Thread<VM>& thread, PC pc, Pos pos) {
      return x.imp->call(thread, pc, pos); }

  template <typename VM>
  /*constexpr*/ bool operator==(const Val<VM>& x, const Val<VM>& y) { return x.imp->eq(y); }

  template <typename VM>
  /*constexpr*/ bool operator>(const Val<VM>& x, const Val<VM>& y) { return x.imp->gt(y); }

  template <typename VM>
  /*constexpr*/ bool operator<(const Val<VM>& x, const Val<VM>& y) { return x.imp->lt(y); }

  template <typename VM>
  inline Val<VM> operator+(const Val<VM>& x, const Val<VM>& y) { return x.imp->add(y); }

  template <typename VM>
  inline Val<VM> operator-(const Val<VM>& x, const Val<VM>& y) { return x.imp->sub(y); }

  template <typename VM>
  inline void dump(const Val<VM> &v, ostream &out) { v.imp->dump(out); }

  template <typename VM>
  inline void say(const Val<VM> &v, ostream &out) { v.imp->say(out); }
  
  template <typename VM>
  inline ostream &operator<<(ostream &out, const Val<VM> &v) {
    say(v, out);
    return out;
  }

  template <typename VM>
  inline bool is_true(const Val<VM>& x) { return x.imp->is_true(); }
}

#endif
