#ifndef LGPP_PAIR_HPP
#define LGPP_PAIR_HPP

#include <utility>
#include "lgpp/val.hpp"

namespace lgpp {
  template<typename VM>
  struct Val;
  template<typename VM>
  using Pair = pair<Val<VM>, Val<VM>>;
}

#endif
