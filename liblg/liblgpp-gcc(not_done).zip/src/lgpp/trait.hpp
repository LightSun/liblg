#ifndef LGPP_TRAIT_HPP
#define LGPP_TRAIT_HPP

#include <map>
#include <string>

namespace lgpp {
  using namespace std;

  template <typename VM>
  struct Trait {
    using TraitType = Trait<VM>;

    Trait(VM& vm, string name, initializer_list<TraitType *> parents = {}): vm(vm), name(name) {
      for (auto p: parents) { derive(*this, *p, *p); }
    }
    
    Trait(const TraitType &) = delete;
    Trait &operator =(const TraitType &) = delete;

    VM& vm;
    const string name;
    map<TraitType *, TraitType *> isa;
  };

  template <typename VM>
  inline void derive(Trait<VM> &child, Trait<VM> &parent, Trait<VM> &root){
      child.isa.insert(make_pair(&parent, &root));
      for (const auto &[p, r]: parent.isa) { derive(child, *p, *r); }
  }

//  inline void derive(Trait<VM> &child, Trait<VM> &parent, Trait<VM> &root) {
//    child.isa.insert(make_pair(&parent, &root));
//    for (const auto &[p, r]: parent.isa) { derive(child, *p, *r); }
//  }
  template <typename VM>
  inline Trait<VM> *isa(Trait<VM> &child, Trait<VM> &parent) {
    auto found = child.isa.find(&parent);
    if (found == child.isa.end()) { return nullptr; }
    return found->second;
  }
}

#endif
