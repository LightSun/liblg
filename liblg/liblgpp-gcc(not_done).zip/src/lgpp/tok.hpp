#ifndef LGPP_TOK_HPP
#define LGPP_TOK_HPP

#include <deque>
#include <ostream>

#include "lgpp/env.hpp"
#include "lgpp/pos.hpp"

namespace lgpp {
  template<typename VM>
  struct Parser;
  template <typename VM>
  struct Thread;
  template <typename VM>
  struct Tok;

  template <typename VM>
  using Toque = deque<Tok<VM>>;

  namespace toks {
    template <typename VM, typename T>
    void compile(const Tok<VM>& tok, const T& imp, Toque<VM>& in, Thread<VM>& out, Env<VM>& env) {}

    template <typename VM,typename T>
    void dump(const Tok<VM>& tok, const T& imp, ostream& out);
  }

  template <typename VM0>
  struct Tok {
    template <typename VM>
    struct Imp {
      virtual ~Imp() = default;
      virtual void compile(const Tok<VM>& tok, Toque<VM>& in, Thread<VM>& out, Env<VM>& env) const = 0;
      virtual void dump(const Tok<VM>& tok, ostream& out) const = 0;
    };

    template <typename VM,typename T>
    struct TImp: Imp<VM>{
      TImp(T imp): imp(move(imp)) { }

      void compile(const Tok<VM>& tok, Toque<VM>& in, Thread<VM>& out, Env<VM>& env) const override {
          toks::compile(tok, imp, in, out, env);
      }
      
      void dump(const Tok<VM>& tok, ostream& out) const override { toks::dump(tok, imp, out); }

      T imp;
    };

    template <typename T>
    Tok(Pos pos, T imp): pos(pos), imp(make_shared<TImp<VM0,T>>(move(imp))) { }

    template <typename T>
    const T& as() const { return dynamic_cast<const TImp<VM0,T>&>(*imp).imp; }

    template <typename T>
    const T* try_as() const {
      auto timp = dynamic_cast<const TImp<VM0,T> *>(imp.get());
      return timp ? &timp->imp : nullptr;
    }

    Pos pos;
    shared_ptr<const Imp<VM0>> imp;
  };

  template <typename VM>
  inline void compile(const Tok<VM> &tok, Toque<VM>& in, Thread<VM>& out, Env<VM>& env) {
      return tok.imp->compile(tok, in, out, env);
  }

  template <typename VM>
  inline void dump(const Tok<VM> &tok, ostream& out) { return tok.imp->dump(tok, out); }

  template <typename VM>
  inline ostream &operator<<(ostream &out, const Tok<VM> &t) {
    t.imp->dump(t, out);
    return out;
  }

  template <typename VM, typename T, typename...Args>
  const Tok<VM>& push(Toque<VM>& in, Pos pos, Args&&...args) {
    return in.emplace_back(pos, T(forward<Args>(args)...));
  }
  
  template <typename VM>
  inline optional<Tok<VM>> peek(const Toque<VM>& in) {
    return in.empty() ? nullopt : make_optional(in.front());
  }

  template <typename VM>
  inline Tok<VM> pop(Toque<VM>& in) {
    if (in.empty()) { throw runtime_error("Missing token"); }
    Tok<VM> t = in.front();
    in.pop_front();
    return t;
  }

  template <typename VM>
  inline Tok<VM> pop_back(Toque<VM>& in) {
    if (in.empty()) { throw runtime_error("Missing token"); }
    Tok t = in.back();
    in.pop_back();
    return t;
  }
}

#endif
