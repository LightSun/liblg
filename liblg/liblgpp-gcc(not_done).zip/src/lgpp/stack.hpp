#ifndef LGPP_STACK_HPP
#define LGPP_STACK_HPP

#include <ostream>
#include <vector>
#include "val.hpp"

namespace lgpp {

  using namespace std;
  
  template <typename VM>
  using Stack = vector<Val<VM>>;

  template <typename VM,typename...Args>
  void push(Stack<VM>& stack, Args&&...args) { stack.emplace_back(forward<Args>(args)...); }

  template <typename VM>
  inline Val<VM> pop(Stack<VM>& stack) {
    if (stack.empty()) { throw runtime_error("Stack is empty"); }
    Val<VM> v(stack.back());
    stack.pop_back();
    return v;
  } 

  template <typename VM,typename T>
  T pop(Stack<VM>& stack, Type<VM,T>& type) { return pop(stack).as(type); }

  template <typename VM,typename T>
  const T &peek(Stack<VM>& stack, Type<VM, T>& type) {
    if (stack.empty()) { throw runtime_error("Stack is empty"); }
    return stack.back().as(type);
  } 

  template <typename VM>
  inline void dump(const Stack<VM> &stack, ostream &out) {
    out << '[';
    auto i = 0;
    
    for (auto v: stack) {
      if (i++) { out << ' '; }
      v.imp->dump(out);
    }
    
    out << ']';
  };
  template <typename VM>
  inline ostream &operator<<(ostream &out, const Stack<VM> &s) {
    dump(s, out);
    return out;
  }
}

#endif
