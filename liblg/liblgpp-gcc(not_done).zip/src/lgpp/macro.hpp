#ifndef LGPP_MACRO_HPP
#define LGPP_MACRO_HPP

#include "lgpp/env.hpp"
#include "lgpp/tok.hpp"

namespace lgpp {

 template<typename VM>  
  struct Parser;
  template<typename VM>
  struct Thread;
  
  template<typename VM>
  struct Macro {
    using Imp = function<void (Toque<VM> &, Thread<VM> &, Env<VM> &)>;

    Macro(string name, Imp imp): name(name), imp(imp) {}

    const string name;
    Imp imp;
  };

}

#endif
