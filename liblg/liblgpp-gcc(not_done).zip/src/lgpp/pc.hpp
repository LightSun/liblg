#ifndef LGPP_PC_HPP
#define LGPP_PC_HPP

#include <cstddef>

namespace lgpp {
  using PC = size_t;
}

#endif
