#ifndef LGPP_TYPES_BOOL_HPP
#define LGPP_TYPES_BOOL_HPP

#include "lgpp/type.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM, bool>& type, const bool& x, ostream &out) { out << (x ? 'T' : 'F'); }

  template <typename VM>
  inline bool is_true(Type<VM, bool>& type, const bool& x) { return x; }

}

#endif
