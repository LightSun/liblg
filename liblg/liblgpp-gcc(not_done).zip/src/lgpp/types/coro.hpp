#ifndef LGPP_TYPES_CORO_HPP
#define LGPP_TYPES_CORO_HPP

#include "lgpp/type.hpp"
#include "lgpp/coro.hpp"
#include "lgpp/thread.hpp"

namespace lgpp::types {

  template <typename VM>
  inline PC call(Type<VM,lgpp::Coro>& type, const lgpp::Coro& imp,
                 Thread<VM>& thread, PC return_pc, Pos pos) {
    return resume(imp, thread, return_pc, pos); 
  }

}

#endif
