#ifndef LGPP_TYPES_MACRO_HPP
#define LGPP_TYPES_MACRO_HPP

#include "lgpp/type.hpp"
#include "lgpp/macro.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM,lgpp::Macro<VM>>& type, const lgpp::Macro<VM>& x, ostream &out)
    { out << "(Macro " << x.name << ')';
  }

  template <typename VM>
  inline bool eq(Type<VM,lgpp::Macro<VM>>& type, const lgpp::Macro<VM>& x, Val<VM> y) {
      return x.name == y.as(type).name; }
  
  template <typename VM>
  inline bool gt(Type<VM,lgpp::Macro<VM>>& type, const lgpp::Macro<VM>& x, Val<VM> y) {
      return x.name > y.as(type).name; }
  
  template <typename VM>
  inline bool lt(Type<VM,lgpp::Macro<VM>>& type, const lgpp::Macro<VM>& x, Val<VM> y) {
      return x.name < y.as(type).name; }

}

#endif
