#ifndef LGPP_TYPES_LABEL_HPP
#define LGPP_TYPES_LABEL_HPP

#include "lgpp/pc.hpp"
#include "lgpp/type.hpp"
#include "lgpp/label.hpp"
#include "lgpp/thread.hpp"

namespace lgpp::types {

  template <typename VM>
  inline PC call(Type<VM, lgpp::Label*>& type, lgpp::Label* const& imp,
                 Thread<VM>& thread, PC return_pc, Pos pos) {
    PC pc = *imp->pc;
    push_call(thread, pc, return_pc);	
    return pc; 
  }

  template <typename VM>
  inline void dump(Type<VM,lgpp::Label*>& type, lgpp::Label* const& x, ostream &out) {
    out << '(' << type.name << ' ';
    if (x->name) { out << *x->name; } else { out << x; }
    out << ')';
  }

}

#endif
