#ifndef LGPP_TYPES_PRIM_HPP
#define LGPP_TYPES_PRIM_HPP

#include "lgpp/prim.hpp"
#include "lgpp/type.hpp"

namespace lgpp::types {

  template <typename VM>
  inline PC call(Type<VM,lgpp::Prim<VM>>& type, const lgpp::Prim<VM>& imp,
                 Thread<VM>& thread, PC return_pc, Pos pos) {
    imp.imp(thread, pos);
    return return_pc;
  }

  template <typename VM>
  inline void dump(Type<VM,lgpp::Prim<VM>>& type, const lgpp::Prim<VM>& x, ostream &out)
  { out << "(Prim " << x.name << ')'; }

  template <typename VM>
  inline bool eq(Type<VM,lgpp::Prim<VM>>& type, const lgpp::Prim<VM>& x, Val<VM> y) {
      return x.name == y.as(type).name; }
  
  template <typename VM>
  inline bool gt(Type<VM,lgpp::Prim<VM>>& type, const lgpp::Prim<VM>& x, Val<VM> y) {
      return x.name > y.as(type).name; }
  
  template <typename VM>
  inline bool lt(Type<VM,lgpp::Prim<VM>>& type, const lgpp::Prim<VM>& x, Val<VM> y) {
      return x.name < y.as(type).name; }

}

#endif
