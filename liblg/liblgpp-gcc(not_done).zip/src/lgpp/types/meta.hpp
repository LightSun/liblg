#ifndef LGPP_TYPES_META_HPP
#define LGPP_TYPES_META_HPP

#include "lgpp/type.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM,lgpp::Trait<VM>*>& type, lgpp::Trait<VM>* const& x, ostream &out) {
      out << x->name; }

}

#endif
