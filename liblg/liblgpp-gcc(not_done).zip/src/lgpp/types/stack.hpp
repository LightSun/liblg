#ifndef LGPP_TYPES_STACK_HPP
#define LGPP_TYPES_STACK_HPP

#include "lgpp/type.hpp"
#include "lgpp/stack.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM,lgpp::Stack<VM>>& type, const lgpp::Stack<VM>& x, ostream &out) {
      dump(x, out); }

  template <typename VM>
  inline void say(Type<VM,lgpp::Stack<VM>>& type, const lgpp::Stack<VM>& x, ostream &out) {
    for (auto v: x) { v.imp->say(out); }
  }

  template <typename VM>
  inline bool is_true(Type<VM,lgpp::Stack<VM>>& type, const lgpp::Stack<VM>& x) {
      return !x.empty(); }

}

#endif
