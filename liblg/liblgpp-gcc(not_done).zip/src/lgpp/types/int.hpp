#ifndef LGPP_TYPES_INT_HPP
#define LGPP_TYPES_INT_HPP

#include "lgpp/type.hpp"
#include "lgpp/val.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM,int>& type, const int& x, ostream &out) { out << x; }

  template <typename VM>
  inline bool is_true(Type<VM,int>& type, const int& x) { return x; }

  template <typename VM>
  inline Val<VM> add(Type<VM,int>& type, const int& x, Val<VM> y) {
      return Val(type, x + y.as(type)); }
  
  template <typename VM>
  inline Val<VM> sub(Type<VM,int>& type, const int& x, Val<VM> y) {
      return Val(type, x - y.as(type)); }

}

#endif
