#ifndef LGPP_TYPES_PAIR_HPP
#define LGPP_TYPES_PAIR_HPP

#include "lgpp/type.hpp"
#include "lgpp/pair.hpp"

namespace lgpp::types {

  template <typename VM>
  inline void dump(Type<VM, lgpp::Pair<VM>>& type, const lgpp::Pair<VM>& x, ostream &out) {
    out << '<';
    dump(x.first, out);
    out << ' ';
    dump(x.second, out);
    out << '>';
  }

  template <typename VM>
  inline void say(Type<VM,lgpp::Pair<VM>>& type, const lgpp::Pair<VM>& x, ostream &out) {
    say(x.first, out);
    say(x.second, out);
  }

}

#endif
