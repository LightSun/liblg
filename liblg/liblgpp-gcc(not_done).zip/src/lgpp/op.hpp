#ifndef LGPP_OP_HPP
#define LGPP_OP_HPP

#include <memory>
#include <utility>

#include "lgpp/pc.hpp"
#include "lgpp/pos.hpp"
#include "lgpp/stack.hpp"

namespace lgpp {
  using namespace std;

  template <typename VM>
  struct Op;

  template <typename VM>
  struct Thread;
  
  namespace ops {
    template <typename VM,typename T>
    const Op<VM>* eval(const Op<VM>& op, const T& imp, lgpp::Thread<VM>& thread);
  }
  
  template <typename VM0>
  struct Op {
    template <typename VM>
    struct Imp {
      virtual ~Imp() = default;
      virtual const Op* eval(const Op& op, lgpp::Thread<VM>& thread) const = 0;
    };

    template <typename VM, typename T>
    struct TImp: Imp<VM> {
      TImp(T imp): imp(move(imp)) { }

      const Op* eval(const Op& op, lgpp::Thread<VM>& thread) const override {
          return ops::eval(op, imp, thread);
      }

      T imp;
    };

    template <typename T>
    Op(PC pc, Pos pos, T imp): pc(pc), pos(pos), imp(make_shared<TImp<VM0,T>>(move(imp))) { }

    template <typename T>
    const T& as() { return dynamic_cast<const TImp<VM0,T>&>(*imp).imp; }
    
    const PC pc;
    const Pos pos;
    shared_ptr<const Imp<VM0>> imp;
  };

  template <typename VM>
  inline const Op<VM> *eval(const Op<VM>& op, lgpp::Thread<VM>& thread) {
      return op.imp->eval(op, thread);
  }

}

#endif
