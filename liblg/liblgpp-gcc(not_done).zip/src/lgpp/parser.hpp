#ifndef LGPP_PARSER_HPP
#define LGPP_PARSER_HPP

#include <optional>
#include <sstream>

#include "lgpp/error.hpp"
#include "lgpp/toks/group.hpp"
#include "lgpp/toks/id.hpp"
#include "lgpp/toks/lit.hpp"

namespace lgpp {
  using namespace std;

  template<typename VM>
  struct Parser;
  
  template<typename VM>
  bool parse_id(Parser<VM>&, char, istream&);

  template<typename VM>
  bool parse_int(Parser<VM>&, char, istream&);

  template<typename VM>
  using Alt = function<bool (Parser<VM>&, char, istream&)>;

  template<typename VM>
  struct Parser {
    using Alt = function<bool (Parser<VM>&, char, istream&)>;
    Parser(VM& vm, string file): vm(vm), pos(move(file)) {}

    VM& vm;
    Pos pos;
    Toque<VM> toks;
    deque<Alt> alts;
  };

  template <typename VM, typename T, typename...Args>
  const Tok<VM>& push(Parser<VM>& parser, Pos pos, Args&&...args) {
      return push<VM,T>(parser.toks, pos, forward<Args>(args)...); }
  
  template <typename VM>
  inline optional<Tok<VM>> peek(const Parser<VM>& parser) {
      return peek(parser.toks); }

  template <typename VM>
  inline Tok<VM> pop(Parser<VM>& parser) { return pop(parser.toks); }

  template <typename VM>
  inline Tok<VM> pop_back(Parser<VM>& parser) { return pop_back(parser.toks); }

  template <typename VM>
  inline size_t skip(Parser<VM> &parser, istream &in) {
    size_t n = 0;
    char c = 0;
    
    while (in.get(c)) {
      if (!isspace(c)) {
	in.unget();
	break;
      }
	  
      switch (c) {
      case ' ':
      case '\t':
	parser.pos.col++;
	n++;
        break;
      case '\n':
        parser.pos.row++;
        parser.pos.col = Pos::START_COL;
	n++;
	break;
      };
    }
    
    return n;
  }
  
  template <typename VM>
  inline bool parse_id_pred(Parser<VM>& parser, char c, istream& in,
                            function<bool (char c)> pred) {
    if (!isgraph(c)) { return false; }
    auto p(parser.pos);
    stringstream buf;

    for (;;) {  
      buf << c;
      parser.pos.col++;

      if (!in.get(c) || !isgraph(c) || (pred && !pred(c))) {
        in.unget();
        break;
      }
    }

    if (!buf.tellp()) { return false; }
    push<VM, toks::Id>(parser, p, buf.str());
    return true;
  }
template <typename VM>
  inline bool parse_id(Parser<VM>& parser, char c, istream& in) {
      return parse_id_pred(parser, c, in, nullptr); }

template <typename VM>
  int parse_int_base(Parser<VM> &parser, char c, istream &in, int base) {
    int v(0);
    
    static map<char, int8_t> char_vals = {
      {'0', 0}, {'1', 1}, {'2', 2}, {'3', 3}, {'4', 4}, {'5', 5}, {'6', 6}, {'7', 7},
      {'8', 8}, {'9', 9}, {'a', 10}, {'b', 11}, {'c', 12}, {'d', 13}, {'e', 14},
      {'f', 15}
    };
    
    auto ci(char_vals.end());
    
    do {
      if ((ci = char_vals.find(c)) == char_vals.end()) { break; }
      auto cv(ci->second);
      if (cv >= base) { throw EParse(parser.pos, "Invalid integer: ", c); }
      v = v * base + cv;
      parser.pos.col++;
    } while (in.get(c));
    
    if (!in.eof()) { in.unget();}
    return v;
  }
  
  template <typename VM>
  inline bool parse_int(Parser<VM>& parser, char c, istream& in) {
    if (!isdigit(c)) { return false; }
    auto p = parser.pos;
    push<VM, toks::Lit<VM>>(parser, p, parser.vm.Int, parse_int_base(parser, c, in, 10));
    return true;
  }
  template <typename VM>
  inline bool parse_tok(Parser<VM>& parser, istream& in) {
    if (char c = 0; in.get(c)) {
      for (auto &a: parser.alts) {
	if (a(parser, c, in)) { return true; }
      }

      throw EParse(parser.pos, "Unexpected input: '", c, "'");
    }

    return false;
  }

  template <typename VM,typename T = toks::Group<VM>>
  Alt<VM> parse_group(char beg, char end) {
    return [beg, end](Parser<VM>& parser, char c, istream& in) -> bool {
      if (c != beg) { return false; }
      Pos p = parser.pos;
      vector<Tok<VM>> toks;
      auto i = parser.toks.size();

      for(;;) {
	skip(parser, in);
	if (!in.get(c)) { throw EParse(parser.pos, "Missing end of expression: ", end); }
	if (c == end) { break; }
	in.unget();
	if (!parse_tok(parser, in)) { throw EParse(parser.pos, "Invalid token"); }
      }

      move(parser.toks.begin() + i, parser.toks.end(), back_inserter(toks));
      parser.toks.erase(parser.toks.begin() + i, parser.toks.end());
      push<VM, T>(parser, p, toks);
      return true;
    };
  }

  template <typename VM>
  inline void parse(Parser<VM>& parser, string in) {
    istringstream is(in);
    
    for (;;) {
      skip(parser, is);
      if (!parse_tok(parser, is)) { break; }
    }
  }

  template <typename VM>
  inline void compile(Parser<VM>& parser, Thread<VM>& out, Env<VM>& env) {
    while (!parser.toks.empty()) { compile(pop(parser), parser.toks, out, env); }
  }
}

#endif
