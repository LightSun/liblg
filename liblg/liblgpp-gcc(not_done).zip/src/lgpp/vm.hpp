#ifndef LGPP_VM_HPP
#define LGPP_VM_HPP

#include <map>
#include <shared_mutex>
#include <vector>

#include "lgpp/macro.hpp"
#include "lgpp/op.hpp"
#include "lgpp/pair.hpp"
#include "lgpp/stack.hpp"
#include "lgpp/thread.hpp"
#include "lgpp/type.hpp"
#include "lgpp/call.hpp"

#include "lgpp/types/bool.hpp"
#include "lgpp/types/coro.hpp"
#include "lgpp/types/int.hpp"
#include "lgpp/types/label.hpp"
#include "lgpp/types/macro.hpp"
#include "lgpp/types/meta.hpp"
#include "lgpp/types/pair.hpp"
#include "lgpp/types/prim.hpp"
#include "lgpp/types/stack.hpp"

namespace lgpp {

  using namespace std;

  struct VM;
  
  template <typename...Args>
  Thread<VM>& start_thread(VM &vm, Args&&...args);

  Thread<VM>& get_thread(VM &vm, Thread<VM>::Id id = this_thread::get_id());

  const Thread<VM>& get_thread(const VM &vm, Thread<VM>::Id id = this_thread::get_id());

  struct VM {
    using shared_lock_t = shared_lock<shared_mutex>;
    using lock_t = unique_lock<shared_mutex>;

    VM();
    virtual ~VM();
    
    Trait<VM> Any, Num, Seq;

    Type<VM,bool> Bool;
    Type<VM,lgpp::Coro> Coro;
    Type<VM,int> Int;
    Type<VM,lgpp::Label *> Label;
    Type<VM,lgpp::Macro<VM>> Macro;
    Type<VM,lgpp::Trait<VM> *> Meta;
    Type<VM,lgpp::Pair<VM>> Pair;
    Type<VM,lgpp::Prim<VM>> Prim;
    Type<VM,lgpp::Stack<VM>> Stack;
    Type<VM,Thread<VM>::Id> Thread;
    
    map<lgpp::Thread<VM>::Id, lgpp::Thread<VM>> threads;
    shared_mutex thread_mutex;
    lgpp::Thread<VM> *thread_cache;
  };

  template <typename T, typename...Args>
  const T& emit(VM &vm, Args&&...args) { return emit<VM, T, Args...>(
                  get_thread(vm), forward<Args>(args)...); }
  
  inline PC emit_pc(const VM &vm) { return emit_pc(get_thread(vm)); }

  inline const Op<VM>& eval(VM &vm, const Op<VM>& start_op) {
      return eval(get_thread(vm), start_op); }

  inline const Op<VM>& eval(VM &vm, PC start_pc) {
      return eval(get_thread(vm), start_pc);
  }

  template <typename...Args>
  void push_call(VM &vm, Args&&...args) { push_call(get_thread(vm), forward<Args>(args)...); }
  
  inline Call pop_call(VM &vm) { return pop_call(get_thread(vm)); }
  
  template <typename...Args>
  Thread<VM>& start_thread(VM &vm, Args&&...args) {
    Thread t(vm, forward<Args>(args)...);
    VM::lock_t lock(vm.thread_mutex);
    return vm.threads.insert(make_pair(t.id, move(t))).first->second;
  }

  inline Thread<VM>& get_thread(VM &vm, Thread<VM>::Id id) {
    VM::shared_lock_t lock(vm.thread_mutex);

    if (vm.thread_cache->id != id) {
      auto found = vm.threads.find(id);
      if (found == vm.threads.end()) { throw runtime_error("Thread not found"); }
      vm.thread_cache = &found->second;
    }
    
    return *vm.thread_cache;
  }

  inline const Thread<VM>& get_thread(const VM &vm, Thread<VM>::Id id) {
      return get_thread(const_cast<VM &>(vm), id);
  }

  inline Stack<VM>& get_stack(VM &vm) { return get_stack(get_thread(vm)); }

}

#endif
