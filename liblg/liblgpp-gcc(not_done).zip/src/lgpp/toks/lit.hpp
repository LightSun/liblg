#ifndef LGPP_TOKS_LIT_HPP
#define LGPP_TOKS_LIT_HPP

#include <lgpp/tok.hpp>
#include <lgpp/ops/push.hpp>

namespace lgpp::toks {

 template <typename VM>
  struct Lit {
    template <typename...Args>
    Lit(Args &&...args): val(forward<Args>(args)...) {}
    Val<VM> val;
  };

  template <typename VM>
  inline void compile(const Tok<VM>& tok, const Lit<VM>& imp, Toque<VM>& in,
                      Thread<VM>& out, Env<VM>& env) {
    emit<ops::Push>(out, tok.pos, imp.val);
  }

 template <typename VM>
  inline void dump(const Tok<VM> &tok, const Lit<VM> &imp, ostream &out) {
    out << "(lit " << imp.val << ')';
  }

}

#endif
