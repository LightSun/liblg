#ifndef LGPP_TOKS_GROUP_HPP
#define LGPP_TOKS_GROUP_HPP

#include <lgpp/tok.hpp>

namespace lgpp::toks {

template<typename VM>
  struct Group {
    template <typename...Args>
    Group(Args&&...args): toks(forward<Args>(args)...) {}
    vector<Tok<VM>> toks;
  };

  template<typename VM>
  inline void compile(const Tok<VM>& tok, const Group<VM>& imp, Toque<VM>& in,
                      Thread<VM>& out, Env<VM>& env) {
    deque<Tok<VM>> ts(imp.toks.begin(), imp.toks.end());
    
    while (!ts.empty()) {
      auto t = ts.front();
      ts.pop_front();
      lgpp::compile(t, ts, out, env);
    }
  }

  template<typename VM>
  inline void dump(const Tok<VM> &tok, const Group<VM> &imp, ostream &out) {
    out << "(group";
    auto i = 0;

    for (auto &t: imp.toks) {
      if (i++) { out << ' '; }
      lgpp::dump(t, out);
    }
    
    out << ')';
  }

}

#endif
